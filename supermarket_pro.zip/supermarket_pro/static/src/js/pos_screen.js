/** @odoo-module **/

import {registry} from "@web/core/registry";
import {useService} from "@web/core/utils/hooks";
import {Component, onMounted, onWillStart, onWillUnmount, useState} from "@odoo/owl";

class SupermarketPosScreen extends Component {
    static template = "supermarket_pro.PosScreen";

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.notification = useService("notification");
        const firstOrder = this._makeOrder(1);
        this.catalogRefreshDelay = 2000;
        this.catalogRefreshTimer = null;
        this.catalogLoadingPromise = null;
        this.onVisibilityChange = () => {
            if (document.visibilityState === "visible") {
                this.refreshCatalog({silent: true});
            }
        };

        this.state = useState({
            loading: true,
            checkoutLoading: false,
            products: [],
            categories: [],
            activeCategoryId: null,
            search: "",
            customerSearch: "",
            customerResults: [],
            showCustomerDropdown: false,
            nextOrderNumber: 2,
            orders: [firstOrder],
            activeOrderId: firstOrder.id,
            lastReceipt: null,
            activeTab: "cart", // "cart" | "payment" | "receipt"
        });

        onWillStart(async () => {
            await this.loadCatalog();
        });

        onMounted(() => {
            this.startCatalogAutoRefresh();
            document.addEventListener("visibilitychange", this.onVisibilityChange);
            window.addEventListener("focus", this.onVisibilityChange);
        });

        onWillUnmount(() => {
            this.stopCatalogAutoRefresh();
            document.removeEventListener("visibilitychange", this.onVisibilityChange);
            window.removeEventListener("focus", this.onVisibilityChange);
        });
    }

    // ══════════════════════════════════════
    // ORDER HELPERS
    // ══════════════════════════════════════

    _makeOrder(number) {
        return {
            id: `order_${number}_${Date.now()}`,
            label: `طلب ${number}`,
            customerId: null,
            customerName: "زبون عام",
            customerPhone: "",
            customerDebt: 0,
            customerAllowCredit: false,
            paymentMethod: "cash",
            amountReceived: "",
            discountAmount: 0,
            discountPct: 0,
            taxPercent: 0,
            notes: "",
            cart: [],
        };
    }

    get activeOrder() {
        return this.state.orders.find((o) => o.id === this.state.activeOrderId) || this.state.orders[0];
    }

    get cartCount() {
        return this.activeOrder.cart.reduce((s, l) => s + l.qty, 0);
    }

    get subtotal() {
        return this.activeOrder.cart.reduce((s, l) => s + l.qty * l.unit_price, 0);
    }

    get discountTotal() {
        return (
            Number(this.activeOrder.discountAmount || 0) +
            (this.subtotal * Number(this.activeOrder.discountPct || 0)) / 100
        );
    }

    get taxableBase() {
        return Math.max(this.subtotal - this.discountTotal, 0);
    }

    get taxAmount() {
        return (this.taxableBase * Number(this.activeOrder.taxPercent || 0)) / 100;
    }

    get total() {
        return this.taxableBase + this.taxAmount;
    }

    get changeAmount() {
        return Number(this.activeOrder.amountReceived || 0) - this.total;
    }

    get cartHasItems() {
        return this.activeOrder.cart.length > 0;
    }

    formatAmount(value) {
        return Number(value || 0).toFixed(2);
    }

    // ══════════════════════════════════════
    // CATALOG
    // ══════════════════════════════════════

    async loadCatalog(options = {}) {
        const {silent = false} = options;
        if (this.catalogLoadingPromise) {
            return this.catalogLoadingPromise;
        }
        if (!silent) {
            this.state.loading = true;
        }
        this.catalogLoadingPromise = this._loadCatalog(silent);
        try {
            await this.catalogLoadingPromise;
        } finally {
            this.catalogLoadingPromise = null;
        }
    }

    async _loadCatalog(silent = false) {
        try {
            const result = await this.orm.call("sm.product", "pos_load_catalog", [], {
                search: this.state.search || false,
                category_id: this.state.activeCategoryId || false,
            });
            this.state.products = result.products || [];
            this.state.categories = result.categories || [];
            this.syncOrdersWithCatalog();
        } finally {
            if (!silent) {
                this.state.loading = false;
            }
        }
    }

    startCatalogAutoRefresh() {
        this.stopCatalogAutoRefresh();
        this.catalogRefreshTimer = window.setInterval(() => {
            this.refreshCatalog({silent: true});
        }, this.catalogRefreshDelay);
    }

    stopCatalogAutoRefresh() {
        if (this.catalogRefreshTimer) {
            window.clearInterval(this.catalogRefreshTimer);
            this.catalogRefreshTimer = null;
        }
    }

    async refreshCatalog(options = {}) {
        try {
            await this.loadCatalog(options);
        } catch {
            // Ignore transient background refresh failures.
        }
    }

    syncOrdersWithCatalog() {
        const productsById = new Map(this.state.products.map((product) => [product.id, product]));
        for (const order of this.state.orders) {
            for (const line of order.cart) {
                const product = productsById.get(line.product_id);
                if (!product) {
                    continue;
                }
                line.name = product.name;
                line.unit_price = product.price;
                line.qty_on_hand = product.qty_on_hand;
                line.unit_label = product.unit_label;
            }
        }
    }

    async onSearchInput(ev) {
        this.state.search = ev.target.value;
        await this.loadCatalog();
    }

    async selectCategory(categoryId) {
        this.state.activeCategoryId = categoryId;
        await this.loadCatalog();
    }

    // ══════════════════════════════════════
    // CUSTOMER SEARCH
    // ══════════════════════════════════════

    async onCustomerSearchInput(ev) {
        this.state.customerSearch = ev.target.value;
        if (!this.state.customerSearch || this.state.customerSearch.length < 1) {
            this.state.customerResults = [];
            this.state.showCustomerDropdown = false;
            return;
        }
        const results = await this.orm.call(
            "sm.customer",
            "pos_search_customers",
            [this.state.customerSearch]
        );
        this.state.customerResults = results;
        this.state.showCustomerDropdown = results.length > 0;
    }

    selectCustomer(customer) {
        const order = this.activeOrder;
        order.customerId = customer.id;
        order.customerName = customer.name;
        order.customerPhone = customer.phone || customer.mobile || "";
        order.customerDebt = customer.total_debt || 0;
        order.customerAllowCredit = customer.allow_credit;
        this.state.customerSearch = customer.name;
        this.state.showCustomerDropdown = false;
        this.state.customerResults = [];
    }

    clearCustomer() {
        const order = this.activeOrder;
        order.customerId = null;
        order.customerName = "زبون عام";
        order.customerPhone = "";
        order.customerDebt = 0;
        order.customerAllowCredit = false;
        this.state.customerSearch = "";
        this.state.showCustomerDropdown = false;
    }

    // ══════════════════════════════════════
    // ORDER MANAGEMENT
    // ══════════════════════════════════════

    createNewOrder() {
        const order = this._makeOrder(this.state.nextOrderNumber);
        this.state.orders.push(order);
        this.state.activeOrderId = order.id;
        this.state.nextOrderNumber += 1;
        this.state.lastReceipt = null;
        this.state.customerSearch = "";
        this.state.activeTab = "cart";
    }

    switchOrder(orderId) {
        if (this.state.activeOrderId === orderId) return;
        this.state.activeOrderId = orderId;
        this.state.lastReceipt = null;
        this.state.activeTab = "cart";
        // مزامنة حقل البحث عن الزبون مع الطلب المختار
        const order = this.state.orders.find((o) => o.id === orderId);
        this.state.customerSearch = order && order.customerId ? order.customerName : "";
    }

    closeOrder(orderId, options = {}) {
        const {preserveReceipt = false} = options;
        if (this.state.orders.length === 1) {
            this.clearOrder({preserveReceipt});
            return;
        }
        const index = this.state.orders.findIndex((o) => o.id === orderId);
        if (index >= 0) this.state.orders.splice(index, 1);
        if (this.state.activeOrderId === orderId) {
            this.state.activeOrderId = this.state.orders[0].id;
        }
        if (!preserveReceipt) this.state.lastReceipt = null;
        this.state.customerSearch = "";
        this.state.activeTab = "cart";
    }

    clearOrder(options = {}) {
        const {preserveReceipt = false} = options;
        const order = this.activeOrder;
        order.customerId = null;
        order.customerName = "زبون عام";
        order.customerPhone = "";
        order.customerDebt = 0;
        order.customerAllowCredit = false;
        order.paymentMethod = "cash";
        order.amountReceived = "";
        order.discountAmount = 0;
        order.discountPct = 0;
        order.taxPercent = 0;
        order.notes = "";
        order.cart.splice(0);
        this.state.customerSearch = "";
        if (!preserveReceipt) this.state.lastReceipt = null;
        this.state.activeTab = "cart";
    }

    // ══════════════════════════════════════
    // CART
    // ══════════════════════════════════════

    addProduct(product) {
        const existing = this.activeOrder.cart.find((l) => l.product_id === product.id);
        if (existing) {
            if (existing.qty + 1 > product.qty_on_hand) {
                this.notification.add("لا يمكن تجاوز الكمية المتوفرة.", {type: "warning"});
                return;
            }
            existing.qty += 1;
        } else {
            this.activeOrder.cart.push({
                product_id: product.id,
                name: product.name,
                unit_price: product.price,
                qty: 1,
                qty_on_hand: product.qty_on_hand,
                unit_label: product.unit_label,
                discount_pct: 0,
            });
        }
        // الانتقال للسلة عند الإضافة
        this.state.activeTab = "cart";
        this.state.lastReceipt = null;
    }

    removeLine(productId) {
        const idx = this.activeOrder.cart.findIndex((l) => l.product_id === productId);
        if (idx >= 0) this.activeOrder.cart.splice(idx, 1);
    }

    changeQty(line, delta) {
        const nextQty = line.qty + delta;
        if (nextQty <= 0) {
            this.removeLine(line.product_id);
            return;
        }
        if (nextQty > line.qty_on_hand) {
            this.notification.add("الكمية المطلوبة أكبر من المتوفر.", {type: "warning"});
            return;
        }
        line.qty = nextQty;
    }

    updateQty(line, ev) {
        const nextQty = Number(ev.target.value || 0);
        if (!nextQty) {
            line.qty = 1;
            return;
        }
        if (nextQty > line.qty_on_hand) {
            this.notification.add("الكمية المطلوبة أكبر من المتوفر.", {type: "warning"});
            line.qty = line.qty_on_hand;
            return;
        }
        line.qty = nextQty;
    }

    // ══════════════════════════════════════
    // TABS
    // ══════════════════════════════════════

    setTab(tab) {
        if (tab === "payment" && !this.cartHasItems) {
            this.notification.add("أضف منتجات أولاً.", {type: "warning"});
            return;
        }
        this.state.activeTab = tab;
    }

    // ══════════════════════════════════════
    // CHECKOUT
    // ══════════════════════════════════════

    async checkout() {
        if (!this.cartHasItems) {
            this.notification.add("أضف منتجات أولاً.", {type: "warning"});
            return;
        }
        if (
            this.activeOrder.paymentMethod === "cash" &&
            Number(this.activeOrder.amountReceived || 0) &&
            this.changeAmount < 0
        ) {
            this.notification.add("المبلغ المستلم أقل من قيمة الفاتورة.", {type: "danger"});
            return;
        }
        if (this.activeOrder.paymentMethod === "credit" && !this.activeOrder.customerId) {
            this.notification.add("يجب اختيار زبون للبيع الآجل.", {type: "danger"});
            return;
        }

        this.state.checkoutLoading = true;
        try {
            const result = await this.orm.call("sm.sale", "pos_create_sale", [
                {
                    customer_id: this.activeOrder.customerId || false,
                    customer_name: this.activeOrder.customerName,
                    customer_phone: this.activeOrder.customerPhone,
                    payment_method: this.activeOrder.paymentMethod,
                    amount_received: Number(this.activeOrder.amountReceived || 0),
                    discount_amount: Number(this.activeOrder.discountAmount || 0),
                    discount_pct: Number(this.activeOrder.discountPct || 0),
                    tax_percent: Number(this.activeOrder.taxPercent || 0),
                    notes: this.activeOrder.notes,
                    items: this.activeOrder.cart.map((l) => ({
                        product_id: l.product_id,
                        qty: l.qty,
                        unit_price: l.unit_price,
                        discount_pct: l.discount_pct || 0,
                    })),
                },
            ]);

            this.state.lastReceipt = result;
            this.notification.add(`✅ تم حفظ البيع ${result.sale_name} بنجاح.`, {type: "success"});

            const currentOrderId = this.activeOrder.id;
            this.closeOrder(currentOrderId, {preserveReceipt: true});
            if (!this.state.orders.length) this.createNewOrder();
            await this.loadCatalog();
            this.state.activeTab = "receipt";
            this.printReceipt(result);
        } catch (error) {
            this.notification.add(error.message || "حدث خطأ أثناء حفظ الفاتورة.", {type: "danger"});
        } finally {
            this.state.checkoutLoading = false;
        }
    }

    // ══════════════════════════════════════
    // RECEIPT
    // ══════════════════════════════════════

    receiptHtml(receipt) {
        const rows = (receipt.items || [])
            .map(
                (item) => `
                <tr>
                    <td>${item.name}</td>
                    <td style="text-align:center">${item.qty}</td>
                    <td style="text-align:center">${Number(item.unit_price).toFixed(2)}</td>
                    <td style="text-align:left">${Number(item.subtotal).toFixed(2)}</td>
                </tr>`
            )
            .join("");

        const debtRow = receipt.amount_debt > 0
            ? `<div class="grand" style="color:#dc2626"><span>الدين المتبقي</span><span>${Number(receipt.amount_debt).toFixed(2)}</span></div>`
            : "";

        return `
            <html dir="rtl">
            <head>
                <meta charset="utf-8"/>
                <title>${receipt.sale_name}</title>
                <style>
                    * { box-sizing: border-box; margin: 0; padding: 0; }
                    body { font-family: Tahoma, Arial, sans-serif; width: 300px; margin: 0 auto; padding: 16px; color: #111; font-size: 13px; }
                    .header { text-align: center; border-bottom: 2px solid #111; padding-bottom: 10px; margin-bottom: 10px; }
                    .header h2 { font-size: 20px; font-weight: 800; }
                    .meta { line-height: 1.8; color: #444; margin-bottom: 10px; }
                    table { width: 100%; border-collapse: collapse; margin: 10px 0; }
                    th { background: #f3f3f3; padding: 6px 4px; font-size: 12px; border-bottom: 1px solid #ddd; }
                    td { border-bottom: 1px dashed #ddd; padding: 5px 4px; }
                    .totals { border-top: 1px solid #111; padding-top: 10px; margin-top: 6px; }
                    .totals div { display: flex; justify-content: space-between; padding: 3px 0; }
                    .grand { font-weight: 800; font-size: 16px; border-top: 1px solid #111; padding-top: 6px; margin-top: 6px; display: flex; justify-content: space-between; }
                    .footer { text-align: center; margin-top: 14px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h2>🏪 السوبر ماركت</h2>
                    <div>${receipt.sale_name} | ${receipt.date || ""}</div>
                </div>
                <div class="meta">
                    <div>الزبون: <strong>${receipt.customer_name || "زبون عام"}</strong></div>
                    <div>الكاشير: ${receipt.cashier || ""}</div>
                    <div>الدفع: ${receipt.payment_method === "cash" ? "نقداً" : receipt.payment_method === "credit" ? "آجل" : receipt.payment_method === "card" ? "بطاقة" : "مختلط"}</div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>الصنف</th>
                            <th>ك</th>
                            <th>سعر</th>
                            <th>إجمالي</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
                <div class="totals">
                    <div><span>المجموع الفرعي</span><span>${Number(receipt.subtotal_amount || 0).toFixed(2)}</span></div>
                    ${receipt.discount_amount > 0 ? `<div><span>الخصم الثابت</span><span>- ${Number(receipt.discount_amount).toFixed(2)}</span></div>` : ""}
                    ${receipt.tax_amount > 0 ? `<div><span>الضريبة</span><span>${Number(receipt.tax_amount).toFixed(2)}</span></div>` : ""}
                </div>
                <div class="grand"><span>الإجمالي النهائي</span><span>${Number(receipt.final_amount || 0).toFixed(2)}</span></div>
                <div class="totals">
                    <div><span>المستلم</span><span>${Number(receipt.amount_received || 0).toFixed(2)}</span></div>
                    <div><span>الباقي للزبون</span><span>${Number(receipt.change_amount || 0).toFixed(2)}</span></div>
                    ${debtRow}
                </div>
                <div class="footer">شكراً لزيارتكم ❤️</div>
            </body>
            </html>`;
    }

    printReceipt(receipt = this.state.lastReceipt) {
        if (!receipt) {
            this.notification.add("لا توجد فاتورة جاهزة للطباعة.", {type: "warning"});
            return;
        }
        const popup = window.open("", "_blank", "width=380,height=680");
        if (!popup) {
            this.notification.add("المتصفح منع نافذة الطباعة. اسمح بالنوافذ المنبثقة.", {type: "warning"});
            return;
        }
        popup.document.open();
        popup.document.write(this.receiptHtml(receipt));
        popup.document.close();
        popup.focus();
        setTimeout(() => popup.print(), 500);
    }

    async openSales() {
        await this.action.doAction("supermarket_pro.action_sm_sale");
    }

    async openCustomers() {
        await this.action.doAction("supermarket_pro.action_sm_customer");
    }
}

registry.category("actions").add("supermarket_pro_pos_screen", SupermarketPosScreen);
