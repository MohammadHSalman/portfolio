from datetime import timedelta

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError


class SmPurchase(models.Model):
    _name = "sm.purchase"
    _description = "فاتورة شراء من المورد"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date desc, id desc"
    _rec_name = "name"

    name = fields.Char(string="رقم الفاتورة", readonly=True, default="جديد", copy=False, index=True)
    date = fields.Date(string="تاريخ الفاتورة", default=fields.Date.today, required=True, tracking=True)
    supplier_id = fields.Many2one("sm.supplier", string="المورد", required=True, tracking=True, ondelete="restrict")
    supplier_phone = fields.Char(string="هاتف المورد", related="supplier_id.phone", readonly=True)
    supplier_invoice_ref = fields.Char(string="رقم فاتورة المورد")

    payment_method = fields.Selection(
        [
            ("cash", "نقداً"),
            ("credit", "آجل"),
            ("bank", "تحويل بنكي"),
            ("check", "شيك"),
        ],
        string="طريقة الدفع",
        default="cash",
        required=True,
        tracking=True,
    )
    due_date = fields.Date(string="تاريخ الاستحقاق")

    line_ids = fields.One2many("sm.purchase.line", "purchase_id", string="تفاصيل المشتريات")
    total_amount = fields.Float(string="المجموع الكلي", compute="_compute_totals", store=True, digits=(10, 2),
                                tracking=True)
    amount_paid = fields.Float(string="المبلغ المدفوع", digits=(10, 2), tracking=True)
    amount_remaining = fields.Float(string="المتبقي للمورد", compute="_compute_totals", store=True, digits=(10, 2))

    state = fields.Selection(
        [
            ("draft", "مسودة"),
            ("confirmed", "مؤكدة"),
            ("paid", "مدفوعة"),
            ("cancelled", "ملغاة"),
        ],
        string="الحالة",
        default="draft",
        tracking=True,
        index=True,
    )
    notes = fields.Text(string="ملاحظات")
    warehouse_note = fields.Char(string="ملاحظة المخزن")

    @api.depends("line_ids.subtotal", "amount_paid")
    def _compute_totals(self):
        for rec in self:
            rec.total_amount = sum(rec.line_ids.mapped("subtotal"))
            rec.amount_remaining = max(rec.total_amount - rec.amount_paid, 0.0)

    @api.onchange("payment_method", "date", "supplier_id")
    def _onchange_payment_terms(self):
        if self.payment_method != "credit":
            self.due_date = False
            return

        days_map = {"15days": 15, "30days": 30, "60days": 60}
        days = days_map.get(self.supplier_id.payment_terms)
        if days and self.date:
            self.due_date = self.date + timedelta(days=days)

    def action_confirm(self):
        for rec in self:
            if not rec.line_ids:
                raise ValidationError("يجب إضافة منتج واحد على الأقل.")

            for line in rec.line_ids:
                if line.qty <= 0:
                    raise ValidationError(f'كمية المنتج "{line.product_id.name}" يجب أن تكون أكبر من صفر.')

            if rec.payment_method == "credit" and not rec.due_date:
                raise ValidationError("يجب تحديد تاريخ استحقاق للفاتورة الآجلة.")

            for line in rec.line_ids:
                line.product_id.qty_on_hand += line.qty
                if line.unit_price > 0 and line.unit_price != line.product_id.cost_price:
                    line.product_id.cost_price = line.unit_price
                if line.expiry_date and line.product_id.has_expiry:
                    line.product_id.expiry_date = line.expiry_date

            if rec.name == "جديد":
                rec.name = self.env["ir.sequence"].next_by_code("sm.purchase") or "PUR/0001"

            if rec.payment_method == "cash":
                rec.amount_paid = rec.total_amount
                rec.state = "paid"
            else:
                rec.state = "confirmed"

            lines = [
                "تم تأكيد فاتورة الشراء.",
                f"المورد: {rec.supplier_id.name}",
                f"المجموع: {rec.total_amount:,.2f}",
                f"عدد الأصناف: {len(rec.line_ids)}",
            ]
            rec.message_post(body="<br/>".join(lines), subject="تأكيد فاتورة شراء")

    def action_mark_paid(self):
        for rec in self:
            rec.amount_paid = rec.total_amount
            rec.state = "paid"
            rec.message_post(
                body=f"تم تسجيل الدفع الكامل للمورد بمبلغ {rec.total_amount:,.2f}.",
                subject="دفع فاتورة مورد",
            )

    def action_partial_pay(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "تسجيل دفعة جزئية",
            "res_model": "sm.partial.pay",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_purchase_id": self.id,
                "default_amount": self.amount_remaining,
            },
        }

    def action_cancel(self):
        for rec in self:
            if rec.state == "paid":
                raise UserError("لا يمكن إلغاء فاتورة مدفوعة.")

            if rec.state == "confirmed":
                for line in rec.line_ids:
                    if line.product_id.qty_on_hand < line.qty:
                        raise UserError(
                            f'لا يمكن الإلغاء لأن كمية المنتج "{line.product_id.name}" الحالية أقل من كمية الفاتورة.'
                        )
                    line.product_id.qty_on_hand -= line.qty

            rec.state = "cancelled"
            rec.message_post(body="تم إلغاء فاتورة الشراء.", subject="إلغاء فاتورة شراء")

    def action_reset_draft(self):
        for rec in self:
            if rec.state != "cancelled":
                raise UserError("يمكن إعادة الفاتورة للمسودة فقط من الحالة الملغاة.")
            rec.state = "draft"


class SmPurchaseLine(models.Model):
    _name = "sm.purchase.line"
    _description = "سطر فاتورة الشراء"
    _order = "id"

    purchase_id = fields.Many2one("sm.purchase", string="الفاتورة", required=True, ondelete="cascade", index=True)
    product_id = fields.Many2one("sm.product", string="المنتج", required=True, ondelete="restrict")
    product_category = fields.Many2one(related="product_id.category_id", string="الفئة", readonly=True)
    qty = fields.Float(string="الكمية المستلمة", default=1.0, required=True, digits=(10, 3))
    unit_price = fields.Float(string="سعر الوحدة", digits=(10, 2), required=True)
    discount_pct = fields.Float(string="خصم %", default=0.0, digits=(6, 2))
    subtotal = fields.Float(string="الإجمالي", compute="_compute_subtotal", store=True, digits=(10, 2))
    expiry_date = fields.Date(string="تاريخ انتهاء هذه الدفعة")
    notes = fields.Char(string="ملاحظة")

    @api.onchange("product_id")
    def _onchange_product_id(self):
        if self.product_id:
            self.unit_price = self.product_id.cost_price or 0.0

    @api.depends("qty", "unit_price", "discount_pct")
    def _compute_subtotal(self):
        for rec in self:
            base = rec.qty * rec.unit_price
            rec.subtotal = base * (1.0 - (rec.discount_pct / 100.0))

    @api.constrains("qty")
    def _check_qty(self):
        for rec in self:
            if rec.qty <= 0:
                raise ValidationError("الكمية يجب أن تكون أكبر من صفر.")


class SmPartialPay(models.TransientModel):
    _name = "sm.partial.pay"
    _description = "دفع جزئي للمورد"

    purchase_id = fields.Many2one("sm.purchase", string="الفاتورة", readonly=True)
    remaining = fields.Float(related="purchase_id.amount_remaining", readonly=True)
    amount = fields.Float(string="المبلغ المدفوع", required=True, digits=(10, 2))
    payment_date = fields.Date(string="تاريخ الدفع", default=fields.Date.today)
    notes = fields.Char(string="ملاحظة")

    def action_pay(self):
        self.ensure_one()
        if self.amount <= 0:
            raise ValidationError("المبلغ يجب أن يكون أكبر من صفر.")
        if self.amount > self.purchase_id.amount_remaining:
            raise ValidationError("المبلغ المدفوع أكبر من المتبقي.")

        self.purchase_id.amount_paid += self.amount
        if self.purchase_id.amount_remaining <= 0:
            self.purchase_id.state = "paid"

        note = f" | {self.notes}" if self.notes else ""
        self.purchase_id.message_post(
            body=f"تم تسجيل دفعة جزئية بقيمة {self.amount:,.2f}{note}",
            subject="دفعة جزئية",
        )
        return {"type": "ir.actions.act_window_close"}
