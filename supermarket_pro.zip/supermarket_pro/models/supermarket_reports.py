from odoo import models


class SmDashboardReports(models.TransientModel):
    _inherit = "sm.dashboard"

    def _action_by_xmlid(self, xmlid, domain=None):
        self.ensure_one()
        action = self.env["ir.actions.actions"]._for_xml_id(xmlid)
        if domain is not None:
            action["domain"] = domain
        return action

    def action_open_sales_report(self):
        self.ensure_one()
        date_from, date_to = self._date_bounds()
        return self._action_by_xmlid(
            "supermarket_pro.action_sm_sale",
            self._sale_domain(date_from, date_to),
        )

    def action_open_products_report(self):
        self.ensure_one()
        return self._action_by_xmlid(
            "supermarket_pro.action_sm_product",
            self._product_domain(),
        )

    def action_open_alerts_report(self):
        self.ensure_one()
        return self._action_by_xmlid(
            "supermarket_pro.action_sm_alerts",
            self._product_domain() + [("needs_attention", "=", True)],
        )

    def action_open_customers_report(self):
        self.ensure_one()
        return self._action_by_xmlid(
            "supermarket_pro.action_sm_customer",
            [("active", "=", True)],
        )

    def action_open_customer_debts_report(self):
        self.ensure_one()
        date_from, date_to = self._date_bounds()
        return self._action_by_xmlid(
            "supermarket_pro.action_sm_customer_debts",
            [
                ("debt_type", "!=", "payment"),
                ("date", ">=", date_from),
                ("date", "<=", date_to),
            ],
        )

    def action_open_purchases_report(self):
        self.ensure_one()
        date_from, date_to = self._date_bounds()
        return self._action_by_xmlid(
            "supermarket_pro.action_sm_purchase",
            self._purchase_domain(date_from, date_to),
        )

    def action_open_suppliers_report(self):
        self.ensure_one()
        domain = [("active", "=", True)]
        if self.supplier_id:
            domain.append(("id", "=", self.supplier_id.id))
        return self._action_by_xmlid(
            "supermarket_pro.action_sm_supplier",
            domain,
        )
