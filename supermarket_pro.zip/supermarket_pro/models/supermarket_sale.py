from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError


class SmSale(models.Model):
    _name = "sm.sale"
    _description = "فاتورة بيع"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "date desc, id desc"
    _rec_name = "name"

    name = fields.Char(string="رقم الفاتورة", readonly=True, default="جديد", copy=False, index=True)
    date = fields.Datetime(string="التاريخ والوقت", default=fields.Datetime.now, required=True, tracking=True)
    sale_type = fields.Selection(
        [("pos", "POS كاشير"), ("invoice", "فاتورة"), ("phone", "طلب هاتفي")],
        string="نوع البيع",
        default="pos",
        required=True,
    )
    cashier = fields.Char(string="الكاشير/البائع", default=lambda self: self.env.user.name)

    # ── الزبون ────────────────────────────────────────────
    customer_id = fields.Many2one(
        "sm.customer",
        string="الزبون",
        ondelete="set null",
        tracking=True,
        index=True,
    )
    customer_name = fields.Char(
        string="اسم الزبون",
        default="زبون عام",
        compute="_compute_customer_name",
        store=True,
        readonly=False,
    )
    customer_phone = fields.Char(string="هاتف الزبون")

    payment_method = fields.Selection(
        [("cash", "نقداً"), ("card", "بطاقة"), ("credit", "آجل"), ("mixed", "مختلط")],
        string="طريقة الدفع",
        default="cash",
        required=True,
        tracking=True,
    )

    # ── دفع الزبون ────────────────────────────────────────
    amount_paid_customer = fields.Float(
        string="المبلغ المدفوع من الزبون",
        digits=(10, 2),
        default=0.0,
        tracking=True,
    )
    amount_debt = fields.Float(
        string="المتبقي (دين)",
        compute="_compute_debt",
        store=True,
        digits=(10, 2),
    )

    line_ids = fields.One2many("sm.sale.line", "sale_id", string="المنتجات")
    subtotal_amount = fields.Float(string="المجموع الفرعي", compute="_compute_totals", store=True, digits=(10, 2))
    discount_amount = fields.Float(string="خصم ثابت", digits=(10, 2), default=0.0, tracking=True)
    discount_pct = fields.Float(string="خصم %", digits=(6, 2), default=0.0)
    tax_percent = fields.Float(string="ضريبة %", digits=(6, 2), default=0.0)
    tax_amount = fields.Float(string="مبلغ الضريبة", compute="_compute_totals", store=True, digits=(10, 2))
    final_amount = fields.Float(string="المبلغ النهائي", compute="_compute_totals", store=True, digits=(10, 2),
                                tracking=True)
    amount_received = fields.Float(string="المبلغ المستلم", digits=(10, 2), default=0.0)
    change_amount = fields.Float(string="الباقي للزبون", compute="_compute_change", digits=(10, 2))

    state = fields.Selection(
        [("draft", "مسودة"), ("confirmed", "مؤكدة"), ("cancelled", "ملغاة")],
        string="الحالة",
        default="draft",
        tracking=True,
        index=True,
    )
    notes = fields.Text(string="ملاحظات")

    @api.depends("customer_id")
    def _compute_customer_name(self):
        for rec in self:
            if rec.customer_id:
                rec.customer_name = rec.customer_id.name
            elif not rec.customer_name:
                rec.customer_name = "زبون عام"

    @api.depends("final_amount", "amount_paid_customer", "payment_method")
    def _compute_debt(self):
        for rec in self:
            if rec.payment_method == "credit":
                rec.amount_debt = max(rec.final_amount - rec.amount_paid_customer, 0.0)
            else:
                rec.amount_debt = 0.0

    @api.depends("line_ids.subtotal", "discount_amount", "discount_pct", "tax_percent")
    def _compute_totals(self):
        for rec in self:
            lines_total = sum(rec.line_ids.mapped("subtotal"))
            rec.subtotal_amount = lines_total
            discount_total = rec.discount_amount + (lines_total * rec.discount_pct / 100.0)
            after_discount = max(lines_total - discount_total, 0.0)
            rec.tax_amount = after_discount * (rec.tax_percent / 100.0)
            rec.final_amount = after_discount + rec.tax_amount

    @api.depends("final_amount", "amount_received")
    def _compute_change(self):
        for rec in self:
            rec.change_amount = rec.amount_received - rec.final_amount

    def action_confirm(self):
        for rec in self:
            if not rec.line_ids:
                raise ValidationError("لا يوجد منتجات في الفاتورة.")

            # التحقق من صحة الدين
            if rec.payment_method == "credit":
                if not rec.customer_id:
                    raise ValidationError("يجب اختيار زبون محدد للبيع الآجل.")
                if not rec.customer_id.allow_credit:
                    raise ValidationError(f'الزبون "{rec.customer_id.name}" غير مسموح له بالدين.')
                if rec.customer_id.credit_limit > 0:
                    new_total_debt = rec.customer_id.total_debt + rec.final_amount - rec.amount_paid_customer
                    if new_total_debt > rec.customer_id.credit_limit:
                        raise ValidationError(
                            f'الدين الجديد ({new_total_debt:,.2f}) يتجاوز حد الائتمان ({rec.customer_id.credit_limit:,.2f}) للزبون "{rec.customer_id.name}".'
                        )

            errors = []
            for line in rec.line_ids:
                if line.qty <= 0:
                    errors.append(f'الكمية للمنتج "{line.product_id.name}" يجب أن تكون أكبر من صفر.')
                elif line.product_id.qty_on_hand < line.qty:
                    errors.append(
                        f'{line.product_id.name}: المتوفر {line.product_id.qty_on_hand} والمطلوب {line.qty}.'
                    )

            if errors:
                raise UserError("يوجد مشاكل في الكميات:\n- " + "\n- ".join(errors))

            if rec.payment_method == "cash" and rec.amount_received and rec.amount_received < rec.final_amount:
                raise UserError("المبلغ المستلم أقل من قيمة الفاتورة.")

            for line in rec.line_ids:
                line.product_id.qty_on_hand -= line.qty

            if rec.name == "جديد":
                rec.name = self.env["ir.sequence"].next_by_code("sm.sale") or "SAL/0001"

            # تسجيل الدفع
            if rec.payment_method == "cash":
                rec.amount_paid_customer = rec.final_amount
            elif rec.payment_method == "card":
                rec.amount_paid_customer = rec.final_amount
            elif rec.payment_method == "credit":
                rec.amount_paid_customer = rec.amount_received or 0.0

            rec.state = "confirmed"

            # تسجيل الدين إن وجد
            if rec.payment_method == "credit" and rec.customer_id and rec.amount_debt > 0:
                self.env["sm.customer.debt"].create({
                    "customer_id": rec.customer_id.id,
                    "sale_id": rec.id,
                    "date": rec.date.date() if rec.date else fields.Date.today(),
                    "debt_type": "sale",
                    "amount": rec.amount_debt,
                    "notes": f"دين من فاتورة {rec.name}",
                })

            payment_label = dict(self._fields["payment_method"].selection).get(rec.payment_method, rec.payment_method)
            rec.message_post(
                body="<br/>".join([
                    "تم تأكيد الفاتورة.",
                    f"الزبون: {rec.customer_name}",
                    f"المبلغ النهائي: {rec.final_amount:,.2f}",
                    f"طريقة الدفع: {payment_label}",
                    f"الدين: {rec.amount_debt:,.2f}" if rec.amount_debt > 0 else "",
                ]),
                subject="تأكيد فاتورة بيع",
            )

    def action_cancel(self):
        for rec in self:
            if rec.state == "confirmed":
                for line in rec.line_ids:
                    line.product_id.qty_on_hand += line.qty
                # حذف سجل الدين المرتبط بهذه الفاتورة
                debt_records = self.env["sm.customer.debt"].search([
                    ("sale_id", "=", rec.id),
                    ("debt_type", "=", "sale"),
                ])
                debt_records.unlink()
                rec.message_post(body="تم إلغاء الفاتورة وإرجاع الكميات إلى المخزون.", subject="إلغاء فاتورة")
            rec.state = "cancelled"

    def action_reset_draft(self):
        for rec in self:
            if rec.state != "cancelled":
                raise UserError("يمكن إعادة الفاتورة للمسودة فقط من الحالة الملغاة.")
            rec.name = "جديد"
            rec.state = "draft"

    def action_print_receipt(self):
        self.ensure_one()
        if self.state != "confirmed":
            raise UserError("يمكن طباعة الإيصال فقط بعد تأكيد الفاتورة.")
        raise UserError("طباعة الإيصال غير مفعلة بعد في هذا الإصدار.")

    @api.model
    def pos_create_sale(self, payload):
        payload = payload or {}
        items = payload.get("items") or []
        if not items:
            raise UserError("لا يمكن إتمام البيع بدون أصناف.")

        line_commands = []
        product_ids = []
        for item in items:
            product_id = int(item.get("product_id"))
            qty = float(item.get("qty", 0))
            if qty <= 0:
                raise ValidationError("كل كمية يجب أن تكون أكبر من صفر.")
            product_ids.append(product_id)
            line_commands.append((0, 0, {
                "product_id": product_id,
                "qty": qty,
                "unit_price": float(item.get("unit_price", 0)),
                "discount_pct": float(item.get("discount_pct", 0)),
            }))

        products = {p.id: p for p in self.env["sm.product"].browse(product_ids).exists()}
        if len(products) != len(set(product_ids)):
            raise UserError("بعض المنتجات لم تعد متوفرة، أعد تحميل الشاشة.")

        for item in items:
            product = products[int(item["product_id"])]
            if product.qty_on_hand < float(item["qty"]):
                raise UserError(f'الكمية غير كافية للمنتج "{product.name}".')

        # التحقق من الزبون والدين
        customer_id = payload.get("customer_id")
        payment_method = payload.get("payment_method") or "cash"
        customer = None
        if customer_id:
            customer = self.env["sm.customer"].browse(int(customer_id)).exists()
            if not customer:
                raise UserError("الزبون المحدد غير موجود.")

        if payment_method == "credit":
            if not customer:
                raise UserError("يجب اختيار زبون محدد للبيع الآجل.")
            if not customer.allow_credit:
                raise UserError(f'الزبون "{customer.name}" غير مسموح له بالدين.')

        sale_vals = {
            "sale_type": "pos",
            "customer_name": customer.name if customer else (payload.get("customer_name") or "زبون عام"),
            "customer_phone": customer.phone if customer else (payload.get("customer_phone") or False),
            "payment_method": payment_method,
            "discount_amount": float(payload.get("discount_amount", 0)),
            "discount_pct": float(payload.get("discount_pct", 0)),
            "tax_percent": float(payload.get("tax_percent", 0)),
            "notes": payload.get("notes") or False,
            "cashier": self.env.user.name,
            "line_ids": line_commands,
        }
        if customer:
            sale_vals["customer_id"] = customer.id

        sale = self.create(sale_vals)

        amount_received = float(payload.get("amount_received", 0) or 0)
        if sale.payment_method == "cash":
            sale.amount_received = amount_received or sale.final_amount
        else:
            sale.amount_received = amount_received

        sale.action_confirm()

        return {
            "sale_id": sale.id,
            "sale_name": sale.name,
            "final_amount": sale.final_amount,
            "change_amount": sale.change_amount,
            "customer_name": sale.customer_name,
            "customer_id": sale.customer_id.id if sale.customer_id else False,
            "cashier": sale.cashier,
            "payment_method": sale.payment_method,
            "date": fields.Datetime.to_string(sale.date),
            "subtotal_amount": sale.subtotal_amount,
            "discount_amount": sale.discount_amount,
            "discount_pct": sale.discount_pct,
            "tax_amount": sale.tax_amount,
            "amount_received": sale.amount_received,
            "amount_debt": sale.amount_debt,
            "items": [
                {
                    "name": line.product_id.name,
                    "qty": line.qty,
                    "unit_price": line.unit_price,
                    "subtotal": line.subtotal,
                    "unit": line.unit,
                }
                for line in sale.line_ids
            ],
        }


class SmSaleLine(models.Model):
    _name = "sm.sale.line"
    _description = "سطر فاتورة البيع"
    _order = "id"

    sale_id = fields.Many2one("sm.sale", string="الفاتورة", required=True, ondelete="cascade", index=True)
    product_id = fields.Many2one(
        "sm.product",
        string="المنتج",
        required=True,
        ondelete="restrict",
        domain="[('qty_on_hand', '>', 0), ('active', '=', True)]",
    )
    barcode = fields.Char(related="product_id.barcode", string="الباركود", readonly=True)
    available_qty = fields.Float(related="product_id.qty_on_hand", string="المتوفر", readonly=True, digits=(10, 3))
    qty = fields.Float(string="الكمية", default=1.0, required=True, digits=(10, 3))
    unit_price = fields.Float(string="سعر الوحدة", digits=(10, 2), required=True)
    discount_pct = fields.Float(string="خصم %", default=0.0, digits=(6, 2))
    subtotal = fields.Float(string="الإجمالي", compute="_compute_subtotal", store=True, digits=(10, 2))
    unit = fields.Selection(related="product_id.unit", string="الوحدة", readonly=True)

    @api.onchange("product_id")
    def _onchange_product_id(self):
        if self.product_id:
            self.unit_price = self.product_id.sale_price

    @api.depends("qty", "unit_price", "discount_pct")
    def _compute_subtotal(self):
        for rec in self:
            base = rec.qty * rec.unit_price
            rec.subtotal = base * (1.0 - (rec.discount_pct / 100.0))

    @api.onchange("qty")
    def _check_qty_warning(self):
        if self.product_id and self.qty > self.product_id.qty_on_hand:
            return {
                "warning": {
                    "title": "تحذير",
                    "message": f"الكمية المطلوبة ({self.qty}) أكبر من المتوفر ({self.product_id.qty_on_hand}).",
                }
            }
        return {}

    @api.constrains("qty")
    def _check_qty(self):
        for rec in self:
            if rec.qty <= 0:
                raise ValidationError("الكمية يجب أن تكون أكبر من صفر.")
