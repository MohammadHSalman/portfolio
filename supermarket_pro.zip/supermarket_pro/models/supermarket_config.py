# supermarket_pro/models/supermarket_config.py
from odoo import models, fields, api


class SmCategory(models.Model):
    _name = 'sm.category'
    _description = 'فئة المنتج'
    _order = 'name'

    name = fields.Char(string='اسم الفئة', required=True)
    code = fields.Char(string='الرمز', size=10)
    description = fields.Text(string='الوصف')
    active = fields.Boolean(string='نشط', default=True)
    color = fields.Integer(string='اللون')
    product_count = fields.Integer(
        string='عدد المنتجات',
        compute='_compute_product_count',
        store=False,
    )

    @api.depends('name')
    def _compute_product_count(self):
        for rec in self:
            rec.product_count = self.env['sm.product'].search_count(
                [('category_id', '=', rec.id), ('active', '=', True)]
            )

    def name_get(self):
        result = []
        for rec in self:
            name = f'[{rec.code}] {rec.name}' if rec.code else rec.name
            result.append((rec.id, name))
        return result
