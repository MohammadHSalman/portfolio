# supermarket_pro/models/supermarket_supplier.py
from odoo import models, fields, api


class SmSupplier(models.Model):
    _name = 'sm.supplier'
    _description = 'مورد'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name'
    _rec_name = 'name'

    # ── معلومات أساسية ─────────────────────────────────────
    name = fields.Char(string='اسم المورد', required=True, tracking=True)
    company_name = fields.Char(string='اسم الشركة')
    tax_number = fields.Char(string='الرقم الضريبي')
    active = fields.Boolean(string='نشط', default=True)

    # ── معلومات التواصل ────────────────────────────────────
    phone = fields.Char(string='رقم الهاتف')
    mobile = fields.Char(string='الموبايل')
    email = fields.Char(string='البريد الإلكتروني')
    address = fields.Text(string='العنوان')
    city = fields.Char(string='المدينة')

    # ── معلومات تجارية ─────────────────────────────────────
    payment_terms = fields.Selection([
        ('cash', 'نقداً فوري'),
        ('15days', '15 يوم'),
        ('30days', '30 يوم'),
        ('60days', '60 يوم'),
        ('custom', 'خاص'),
    ], string='شروط الدفع', default='cash')
    credit_limit = fields.Float(string='حد الائتمان', digits=(10, 2))
    notes = fields.Text(string='ملاحظات')

    # ── إحصائيات محسوبة ────────────────────────────────────
    purchase_count = fields.Integer(
        string='عدد الفواتير',
        compute='_compute_purchase_stats',
    )
    total_purchased = fields.Float(
        string='إجمالي المشتريات',
        compute='_compute_purchase_stats',
        digits=(10, 2),
    )
    total_unpaid = fields.Float(
        string='المبلغ غير المدفوع',
        compute='_compute_purchase_stats',
        digits=(10, 2),
    )

    @api.depends('name')
    def _compute_purchase_stats(self):
        for rec in self:
            purchases = self.env['sm.purchase'].search([
                ('supplier_id', '=', rec.id),
                ('state', 'in', ['confirmed', 'paid']),
            ])
            rec.purchase_count = len(purchases)
            rec.total_purchased = sum(purchases.mapped('total_amount'))
            confirmed = purchases.filtered(lambda p: p.state == 'confirmed')
            rec.total_unpaid = sum(confirmed.mapped('amount_remaining'))

    # ── إجراءات ───────────────────────────────────────────
    def action_view_purchases(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': f'مشتريات {self.name}',
            'res_model': 'sm.purchase',
            'view_mode': 'list,form',
            'domain': [('supplier_id', '=', self.id)],
            'context': {'default_supplier_id': self.id},
        }

    def action_new_purchase(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'فاتورة شراء جديدة',
            'res_model': 'sm.purchase',
            'view_mode': 'form',
            'context': {'default_supplier_id': self.id},
            'target': 'current',
        }
