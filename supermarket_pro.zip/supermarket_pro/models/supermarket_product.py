from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SmProduct(models.Model):
    _name = "sm.product"
    _description = "منتج السوبر ماركت"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name"
    _rec_name = "name"

    name = fields.Char(string="اسم المنتج", required=True, tracking=True, index=True)
    barcode = fields.Char(string="الباركود", index=True, copy=False)
    category_id = fields.Many2one("sm.category", string="الفئة", required=True, tracking=True, ondelete="restrict")
    supplier_id = fields.Many2one("sm.supplier", string="المورد الرئيسي", ondelete="set null")
    image = fields.Binary(string="صورة المنتج", attachment=True)
    active = fields.Boolean(string="نشط", default=True)
    notes = fields.Text(string="ملاحظات")

    cost_price = fields.Float(string="سعر التكلفة", digits=(10, 2), tracking=True)
    sale_price = fields.Float(string="سعر البيع", required=True, digits=(10, 2), tracking=True)
    profit_margin = fields.Float(string="هامش الربح %", compute="_compute_margin", store=True, digits=(6, 2))

    qty_on_hand = fields.Float(string="الكمية الحالية", default=0.0, tracking=True, digits=(10, 3))
    min_qty = fields.Float(
        string="الحد الأدنى للتنبيه",
        default=5.0,
        digits=(10, 3),
        help="عند الوصول لهذا الحد يظهر تنبيه بالنقص.",
    )
    max_qty = fields.Float(
        string="الكمية المستهدفة",
        default=100.0,
        digits=(10, 3),
        help="الكمية المناسبة بعد إعادة الطلب.",
    )
    reorder_qty = fields.Float(
        string="كمية إعادة الطلب",
        compute="_compute_reorder",
        digits=(10, 3),
        help="الكمية المقترحة = الكمية المستهدفة - الكمية الحالية.",
    )
    unit = fields.Selection(
        [
            ("piece", "قطعة"),
            ("kg", "كيلوغرام"),
            ("gram", "غرام"),
            ("liter", "لتر"),
            ("ml", "ملليلتر"),
            ("box", "صندوق"),
            ("dozen", "دزينة"),
            ("pack", "علبة"),
            ("meter", "متر"),
        ],
        string="وحدة القياس",
        default="piece",
        required=True,
    )

    has_expiry = fields.Boolean(string="له تاريخ انتهاء", default=True)
    expiry_date = fields.Date(string="تاريخ الانتهاء")
    days_to_expiry = fields.Integer(string="الأيام المتبقية", compute="_compute_expiry_days", store=True)
    expiry_warning_days = fields.Integer(
        string="تنبيه قبل الانتهاء",
        default=7,
        help="عدد الأيام التي يبدأ عندها تنبيه قرب الانتهاء.",
    )

    stock_state = fields.Selection(
        [("ok", "متوفر"), ("low", "مخزون منخفض"), ("empty", "نافد")],
        string="حالة المخزون",
        compute="_compute_all_states",
        store=True,
        tracking=True,
    )
    expiry_state = fields.Selection(
        [("ok", "صالح"), ("soon", "ينتهي قريباً"), ("expired", "منتهي"), ("na", "غير مطبق")],
        string="حالة الصلاحية",
        compute="_compute_all_states",
        store=True,
        tracking=True,
    )
    needs_attention = fields.Boolean(
        string="يحتاج متابعة",
        compute="_compute_all_states",
        store=True,
        help="يتفعل عند نقص المخزون أو قرب انتهاء الصلاحية.",
    )

    @api.depends("cost_price", "sale_price")
    def _compute_margin(self):
        for rec in self:
            if rec.cost_price > 0:
                rec.profit_margin = ((rec.sale_price - rec.cost_price) / rec.cost_price) * 100
            else:
                rec.profit_margin = 0.0

    @api.depends("qty_on_hand", "max_qty")
    def _compute_reorder(self):
        for rec in self:
            rec.reorder_qty = max(rec.max_qty - rec.qty_on_hand, 0.0)

    @api.depends("expiry_date", "has_expiry")
    def _compute_expiry_days(self):
        today = fields.Date.context_today(self)
        for rec in self:
            if rec.has_expiry and rec.expiry_date:
                rec.days_to_expiry = (rec.expiry_date - today).days
            else:
                rec.days_to_expiry = 0

    @api.depends("qty_on_hand", "min_qty", "expiry_date", "has_expiry", "expiry_warning_days", "days_to_expiry")
    def _compute_all_states(self):
        today = fields.Date.context_today(self)
        for rec in self:
            if rec.qty_on_hand <= 0:
                rec.stock_state = "empty"
            elif rec.qty_on_hand <= rec.min_qty:
                rec.stock_state = "low"
            else:
                rec.stock_state = "ok"

            if not rec.has_expiry or not rec.expiry_date:
                rec.expiry_state = "na"
            elif rec.expiry_date < today:
                rec.expiry_state = "expired"
            elif rec.days_to_expiry <= rec.expiry_warning_days:
                rec.expiry_state = "soon"
            else:
                rec.expiry_state = "ok"

            rec.needs_attention = rec.stock_state in ("low", "empty") or rec.expiry_state in ("soon", "expired")

    @api.constrains("sale_price")
    def _check_sale_price(self):
        for rec in self:
            if rec.sale_price <= 0:
                raise ValidationError(f'سعر البيع للمنتج "{rec.name}" يجب أن يكون أكبر من صفر.')

    @api.constrains("min_qty", "max_qty")
    def _check_quantities(self):
        for rec in self:
            if rec.min_qty < 0:
                raise ValidationError("الحد الأدنى لا يمكن أن يكون سالباً.")
            if rec.max_qty < rec.min_qty:
                raise ValidationError("الكمية المستهدفة يجب أن تكون أكبر من أو تساوي الحد الأدنى.")

    @api.constrains("barcode")
    def _check_barcode_unique(self):
        for rec in self.filtered("barcode"):
            duplicate = self.search([("barcode", "=", rec.barcode), ("id", "!=", rec.id)], limit=1)
            if duplicate:
                raise ValidationError(f'الباركود "{rec.barcode}" مستخدم مسبقاً للمنتج "{duplicate.name}".')

    @api.model
    def action_send_daily_alerts(self):
        products = self.search([("needs_attention", "=", True), ("active", "=", True)])
        if not products:
            return True

        today = fields.Date.context_today(self)
        unit_labels = dict(self._fields["unit"].selection)
        low_stock_lines = []
        expiry_lines = []

        for product in products:
            if product.stock_state in ("low", "empty"):
                low_stock_lines.append(
                    "<li>%s: المتوفر %s %s، الحد الأدنى %s، المقترح طلبه %s</li>"
                    % (
                        product.name,
                        product.qty_on_hand,
                        unit_labels.get(product.unit, ""),
                        product.min_qty,
                        product.reorder_qty,
                    )
                )
            if product.expiry_state in ("soon", "expired"):
                expiry_text = "منتهي" if product.expiry_state == "expired" else f"بعد {product.days_to_expiry} يوم"
                expiry_lines.append(
                    "<li>%s: تاريخ الانتهاء %s، الحالة %s</li>"
                    % (product.name, product.expiry_date or "-", expiry_text)
                )

        body_parts = [f"<p><strong>تنبيه السوبر ماركت اليومي - {today}</strong></p>"]
        if low_stock_lines:
            body_parts.append("<p><strong>أصناف تحتاج إعادة طلب:</strong></p><ul>%s</ul>" % "".join(low_stock_lines))
        if expiry_lines:
            body_parts.append("<p><strong>أصناف تحتاج متابعة صلاحية:</strong></p><ul>%s</ul>" % "".join(expiry_lines))
        body = "".join(body_parts)

        for product in products:
            product.message_post(
                body=body,
                subject=f"تنبيه يومي - {today}",
                message_type="notification",
                subtype_xmlid="mail.mt_note",
            )
        return True

    def action_adjust_stock(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": f"تعديل مخزون: {self.name}",
            "res_model": "sm.stock.adjust",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_product_id": self.id,
                "default_new_qty": self.qty_on_hand,
            },
        }

    def action_create_purchase(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": f"طلب شراء: {self.name}",
            "res_model": "sm.purchase",
            "view_mode": "form",
            "target": "current",
            "context": {
                "default_supplier_id": self.supplier_id.id if self.supplier_id else False,
                "default_line_ids": [
                    (
                        0,
                        0,
                        {
                            "product_id": self.id,
                            "qty": self.reorder_qty or self.min_qty or 1.0,
                            "unit_price": self.cost_price,
                        },
                    )
                ],
            },
        }

    @api.model
    def pos_load_catalog(self, search=None, category_id=None):
        domain = [("active", "=", True), ("qty_on_hand", ">", 0)]
        if category_id:
            domain.append(("category_id", "=", int(category_id)))
        if search:
            domain += ["|", "|", ("name", "ilike", search), ("barcode", "ilike", search),
                       ("category_id.name", "ilike", search)]

        products = self.search(domain, limit=120, order="name asc")
        categories = self.env["sm.category"].search([("active", "=", True)], order="name asc")
        unit_labels = dict(self._fields["unit"].selection)

        return {
            "products": [
                {
                    "id": product.id,
                    "name": product.name,
                    "barcode": product.barcode or "",
                    "price": product.sale_price,
                    "qty_on_hand": product.qty_on_hand,
                    "category_id": product.category_id.id,
                    "category_name": product.category_id.name,
                    "unit": product.unit,
                    "unit_label": unit_labels.get(product.unit, product.unit),
                    "expiry_state": product.expiry_state,
                    "has_expiry": product.has_expiry,
                    "image_url": f"/web/image/sm.product/{product.id}/image" if product.image else False,
                }
                for product in products
            ],
            "categories": [
                {
                    "id": category.id,
                    "name": category.name,
                }
                for category in categories
            ],
        }


class SmStockAdjust(models.TransientModel):
    _name = "sm.stock.adjust"
    _description = "تعديل المخزون"

    product_id = fields.Many2one("sm.product", string="المنتج", required=True, readonly=True)
    current_qty = fields.Float(string="الكمية الحالية", related="product_id.qty_on_hand", readonly=True)
    new_qty = fields.Float(string="الكمية الجديدة", required=True, digits=(10, 3))
    difference = fields.Float(string="الفرق", compute="_compute_difference", digits=(10, 3))
    reason = fields.Selection(
        [
            ("count", "جرد فعلي"),
            ("receive", "استلام بضاعة"),
            ("damage", "تلف"),
            ("loss", "فاقد"),
            ("return", "إرجاع"),
            ("other", "أخرى"),
        ],
        string="سبب التعديل",
        default="count",
        required=True,
    )
    notes = fields.Text(string="ملاحظات إضافية")

    @api.depends("current_qty", "new_qty")
    def _compute_difference(self):
        for rec in self:
            rec.difference = rec.new_qty - rec.current_qty

    def action_confirm(self):
        self.ensure_one()
        if self.new_qty < 0:
            raise ValidationError("الكمية لا يمكن أن تكون سالبة.")

        old_qty = self.product_id.qty_on_hand
        self.product_id.qty_on_hand = self.new_qty
        reason_label = dict(self._fields["reason"].selection).get(self.reason, self.reason)
        self.product_id.message_post(
            body="<p>تم تعديل المخزون يدوياً.</p><ul><li>من: %s</li><li>إلى: %s</li><li>السبب: %s</li>%s</ul>"
                 % (
                     old_qty,
                     self.new_qty,
                     reason_label,
                     f"<li>ملاحظات: {self.notes}</li>" if self.notes else "",
                 ),
            subject="تعديل مخزون",
        )
        return {"type": "ir.actions.act_window_close"}
