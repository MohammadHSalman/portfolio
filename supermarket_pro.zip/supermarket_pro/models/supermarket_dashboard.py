from datetime import timedelta

from odoo import api, fields, models


class SmDashboard(models.TransientModel):
    _name = "sm.dashboard"
    _description = "لوحة تحكم السوبر ماركت"

    filter_range = fields.Selection(
        [
            ("today", "اليوم"),
            ("week", "هذا الأسبوع"),
            ("month", "هذا الشهر"),
            ("custom", "فترة مخصصة"),
        ],
        string="الفترة",
        default="today",
    )
    date_from = fields.Date(string="من تاريخ")
    date_to = fields.Date(string="إلى تاريخ")
    category_id = fields.Many2one("sm.category", string="الفئة")
    supplier_id = fields.Many2one("sm.supplier", string="المورد")
    only_attention = fields.Boolean(string="عرض ما يحتاج متابعة فقط")

    # ── إحصائيات المنتجات ──────────────────────────────────
    total_products = fields.Integer(string="إجمالي المنتجات", compute="_compute_all")
    low_stock_count = fields.Integer(string="مخزون منخفض", compute="_compute_all")
    out_of_stock_count = fields.Integer(string="نافد من المخزون", compute="_compute_all")
    expiry_soon_count = fields.Integer(string="تنتهي قريباً", compute="_compute_all")
    expired_count = fields.Integer(string="منتهية الصلاحية", compute="_compute_all")

    # ── إحصائيات المبيعات ──────────────────────────────────
    today_sales_amount = fields.Float(string="قيمة المبيعات", compute="_compute_all", digits=(10, 2))
    today_sales_count = fields.Integer(string="عدد فواتير البيع", compute="_compute_all")
    week_sales_amount = fields.Float(string="متوسط الفاتورة", compute="_compute_all", digits=(10, 2))
    month_sales_amount = fields.Float(string="أعلى فاتورة", compute="_compute_all", digits=(10, 2))

    # ── إحصائيات المشتريات ─────────────────────────────────
    total_unpaid_purchases = fields.Float(string="ديون الموردين", compute="_compute_all", digits=(10, 2))
    pending_purchases = fields.Integer(string="فواتير شراء غير مسددة", compute="_compute_all")
    month_purchase_amount = fields.Float(string="قيمة المشتريات", compute="_compute_all", digits=(10, 2))

    # ── إحصائيات ديون الزبائن ──────────────────────────────
    total_customer_debt = fields.Float(string="إجمالي ديون الزبائن", compute="_compute_all", digits=(10, 2))
    customers_with_debt = fields.Integer(string="زبائن عليهم دين", compute="_compute_all")
    top_debtor_name = fields.Char(string="أعلى دين", compute="_compute_all")
    top_debtor_amount = fields.Float(string="مبلغ أعلى دين", compute="_compute_all", digits=(10, 2))

    # ── إحصائيات عامة ──────────────────────────────────────
    total_suppliers = fields.Integer(string="عدد الموردين", compute="_compute_all")
    total_categories = fields.Integer(string="عدد الفئات", compute="_compute_all")
    total_customers = fields.Integer(string="عدد الزبائن", compute="_compute_all")

    # ── HTML Panels ─────────────────────────────────────────
    sales_summary_html = fields.Html(string="ملخص المبيعات", compute="_compute_all", sanitize=False)
    inventory_summary_html = fields.Html(string="ملخص المخزون", compute="_compute_all", sanitize=False)
    purchases_summary_html = fields.Html(string="ملخص المشتريات", compute="_compute_all", sanitize=False)
    alerts_summary_html = fields.Html(string="ملخص التنبيهات", compute="_compute_all", sanitize=False)
    customer_debt_html = fields.Html(string="ديون الزبائن", compute="_compute_all", sanitize=False)

    # ══════════════════════════════════════════════════════
    # onchange / default_get
    # ══════════════════════════════════════════════════════

    @api.onchange("filter_range")
    def _onchange_filter_range(self):
        today = fields.Date.context_today(self)
        if self.filter_range == "today":
            self.date_from = today
            self.date_to = today
        elif self.filter_range == "week":
            self.date_from = today - timedelta(days=today.weekday())
            self.date_to = today
        elif self.filter_range == "month":
            self.date_from = today.replace(day=1)
            self.date_to = today

    @api.model
    def default_get(self, fields_list):
        values = super().default_get(fields_list)
        today = fields.Date.context_today(self)
        values.setdefault("filter_range", "today")
        values.setdefault("date_from", today)
        values.setdefault("date_to", today)
        return values

    # ══════════════════════════════════════════════════════
    # Domain helpers
    # ══════════════════════════════════════════════════════

    def _date_bounds(self):
        today = fields.Date.context_today(self)
        if self.filter_range == "week":
            return today - timedelta(days=today.weekday()), today
        if self.filter_range == "month":
            return today.replace(day=1), today
        if self.filter_range == "custom":
            return self.date_from or today, self.date_to or today
        return today, today

    def _product_domain(self):
        domain = [("active", "=", True)]
        if self.category_id:
            domain.append(("category_id", "=", self.category_id.id))
        if self.supplier_id:
            domain.append(("supplier_id", "=", self.supplier_id.id))
        if self.only_attention:
            domain.append(("needs_attention", "=", True))
        return domain

    def _sale_domain(self, date_from, date_to):
        domain = [
            ("state", "=", "confirmed"),
            ("date", ">=", fields.Datetime.to_datetime(f"{date_from} 00:00:00")),
            ("date", "<=", fields.Datetime.to_datetime(f"{date_to} 23:59:59")),
        ]
        if self.category_id:
            domain.append(("line_ids.product_id.category_id", "=", self.category_id.id))
        if self.supplier_id:
            domain.append(("line_ids.product_id.supplier_id", "=", self.supplier_id.id))
        return domain

    def _purchase_domain(self, date_from, date_to):
        domain = [
            ("state", "in", ["confirmed", "paid"]),
            ("date", ">=", date_from),
            ("date", "<=", date_to),
        ]
        if self.supplier_id:
            domain.append(("supplier_id", "=", self.supplier_id.id))
        if self.category_id:
            domain.append(("line_ids.product_id.category_id", "=", self.category_id.id))
        return domain

    # ══════════════════════════════════════════════════════
    # Main compute
    # ══════════════════════════════════════════════════════

    @api.depends(
        "filter_range", "date_from", "date_to",
        "category_id", "supplier_id", "only_attention",
    )
    def _compute_all(self):
        Product = self.env["sm.product"]
        Sale = self.env["sm.sale"]
        Purchase = self.env["sm.purchase"]
        Supplier = self.env["sm.supplier"]
        Category = self.env["sm.category"]
        Customer = self.env["sm.customer"]

        for rec in self:
            date_from, date_to = rec._date_bounds()
            product_domain = rec._product_domain()
            sale_domain = rec._sale_domain(date_from, date_to)
            purchase_domain = rec._purchase_domain(date_from, date_to)

            # ── بيانات خام ────────────────────────────────
            products = Product.search(product_domain, order="qty_on_hand asc, expiry_date asc", limit=5)
            sales = Sale.search(sale_domain)
            purchases = Purchase.search(purchase_domain)
            unpaid_purchases = purchases.filtered(lambda p: p.amount_remaining > 0)

            # ── المنتجات ───────────────────────────────────
            rec.total_products = Product.search_count(product_domain)
            rec.low_stock_count = Product.search_count(product_domain + [("stock_state", "=", "low")])
            rec.out_of_stock_count = Product.search_count(product_domain + [("stock_state", "=", "empty")])
            rec.expiry_soon_count = Product.search_count(product_domain + [("expiry_state", "=", "soon")])
            rec.expired_count = Product.search_count(product_domain + [("expiry_state", "=", "expired")])

            # ── المبيعات ───────────────────────────────────
            rec.today_sales_amount = sum(sales.mapped("final_amount"))
            rec.today_sales_count = len(sales)
            rec.week_sales_amount = (
                rec.today_sales_amount / rec.today_sales_count
                if rec.today_sales_count else 0.0
            )
            rec.month_sales_amount = max(sales.mapped("final_amount")) if sales else 0.0

            # ── المشتريات ──────────────────────────────────
            rec.total_unpaid_purchases = sum(unpaid_purchases.mapped("amount_remaining"))
            rec.pending_purchases = len(unpaid_purchases)
            rec.month_purchase_amount = sum(purchases.mapped("total_amount"))

            # ── ديون الزبائن ───────────────────────────────
            all_customers = Customer.search([("active", "=", True), ("total_debt", ">", 0)])
            rec.total_customer_debt = sum(all_customers.mapped("total_debt"))
            rec.customers_with_debt = len(all_customers)

            top_debtor = all_customers.sorted(key=lambda c: c.total_debt, reverse=True)[:1]
            if top_debtor:
                rec.top_debtor_name = top_debtor.name
                rec.top_debtor_amount = top_debtor.total_debt
            else:
                rec.top_debtor_name = "-"
                rec.top_debtor_amount = 0.0

            # ── إحصائيات عامة ─────────────────────────────
            supplier_domain = [("active", "=", True)]
            if rec.supplier_id:
                supplier_domain.append(("id", "=", rec.supplier_id.id))
            rec.total_suppliers = Supplier.search_count(supplier_domain)

            category_domain = [("active", "=", True)]
            if rec.category_id:
                category_domain.append(("id", "=", rec.category_id.id))
            rec.total_categories = Category.search_count(category_domain)
            rec.total_customers = Customer.search_count([("active", "=", True)])

            # ── HTML Panels ────────────────────────────────
            rec.sales_summary_html = rec._build_sales_summary(sales, date_from, date_to)
            rec.inventory_summary_html = rec._build_inventory_summary(products)
            rec.purchases_summary_html = rec._build_purchase_summary(purchases, unpaid_purchases)
            rec.alerts_summary_html = rec._build_alerts_summary(product_domain)
            rec.customer_debt_html = rec._build_customer_debt_summary(all_customers)

    # ══════════════════════════════════════════════════════
    # HTML builders
    # ══════════════════════════════════════════════════════

    def _build_sales_summary(self, sales, date_from, date_to):
        top_sales = sorted(sales, key=lambda s: s.final_amount, reverse=True)[:5]
        rows = "".join(
            f"<li><strong>{s.name}</strong> &mdash; {s.customer_name or 'زبون عام'} &mdash; {s.final_amount:,.2f}</li>"
            for s in top_sales
        ) or "<li>لا توجد مبيعات ضمن الفلاتر الحالية.</li>"
        return (
            f"<div class='sm_dashboard_panel'>"
            f"<div class='sm_dashboard_panel__head'>الفترة التحليلية: {date_from} إلى {date_to}</div>"
            f"<ul class='sm_dashboard_list'>{rows}</ul>"
            f"</div>"
        )

    def _build_inventory_summary(self, products):
        rows = []
        for p in products:
            flags = []
            if p.stock_state in ("low", "empty"):
                flags.append(f"مخزون {dict(p._fields['stock_state'].selection).get(p.stock_state)}")
            if p.expiry_state in ("soon", "expired"):
                flags.append(f"صلاحية {dict(p._fields['expiry_state'].selection).get(p.expiry_state)}")
            unit_label = dict(p._fields["unit"].selection).get(p.unit, "")
            rows.append(
                f"<li><strong>{p.name}</strong> &mdash; المتوفر {p.qty_on_hand} {unit_label}"
                f"{' &mdash; ' + ' | '.join(flags) if flags else ''}</li>"
            )
        body = "".join(rows) or "<li>المخزون ضمن الوضع الطبيعي.</li>"
        return (
            "<div class='sm_dashboard_panel'>"
            "<div class='sm_dashboard_panel__head'>أهم الأصناف التي تحتاج متابعة</div>"
            f"<ul class='sm_dashboard_list'>{body}</ul>"
            "</div>"
        )

    def _build_purchase_summary(self, purchases, unpaid_purchases):
        top = sorted(purchases, key=lambda p: p.total_amount, reverse=True)[:5]
        rows = "".join(
            f"<li><strong>{p.name}</strong> &mdash; {p.supplier_id.name} &mdash; {p.total_amount:,.2f}</li>"
            for p in top
        ) or "<li>لا توجد مشتريات ضمن الفلاتر الحالية.</li>"
        unpaid_note = (
            f"<div class='sm_dashboard_hint'>فواتير غير مسددة: {len(unpaid_purchases)}"
            f" &nbsp;|&nbsp; إجمالي: {sum(unpaid_purchases.mapped('amount_remaining')):,.2f}</div>"
        )
        return (
            "<div class='sm_dashboard_panel'>"
            "<div class='sm_dashboard_panel__head'>ملخص الشراء</div>"
            f"{unpaid_note}<ul class='sm_dashboard_list'>{rows}</ul>"
            "</div>"
        )

    def _build_alerts_summary(self, product_domain):
        Product = self.env["sm.product"]
        low = Product.search_count(product_domain + [("stock_state", "=", "low")])
        empty = Product.search_count(product_domain + [("stock_state", "=", "empty")])
        soon = Product.search_count(product_domain + [("expiry_state", "=", "soon")])
        expired = Product.search_count(product_domain + [("expiry_state", "=", "expired")])
        rows = [
            f"<li>أصناف تحت الحد الأدنى: <strong>{low}</strong></li>",
            f"<li>أصناف نافدة: <strong>{empty}</strong></li>",
            f"<li>أصناف قريبة من الانتهاء: <strong>{soon}</strong></li>",
            f"<li>أصناف منتهية: <strong>{expired}</strong></li>",
        ]
        return (
            "<div class='sm_dashboard_panel'>"
            "<div class='sm_dashboard_panel__head'>حالة التنبيهات الحالية</div>"
            f"<ul class='sm_dashboard_list'>{''.join(rows)}</ul>"
            "</div>"
        )

    def _build_customer_debt_summary(self, customers_with_debt):
        """أعلى 5 زبائن من حيث الدين."""
        top = customers_with_debt.sorted(key=lambda c: c.total_debt, reverse=True)[:5]

        if not top:
            body = "<li>لا توجد ديون مستحقة على الزبائن. 🎉</li>"
        else:
            body = "".join(
                f"""<li>
                        <span class='sm_db_debt_name'>{c.name}</span>
                        <span class='sm_db_debt_phone'>{c.phone or ''}</span>
                        <span class='sm_db_debt_amount'>{c.total_debt:,.2f}</span>
                    </li>"""
                for c in top
            )

        total = sum(customers_with_debt.mapped("total_debt"))
        count = len(customers_with_debt)
        hint = (
            f"<div class='sm_dashboard_hint'>"
            f"إجمالي الديون: <strong>{total:,.2f}</strong>"
            f"&nbsp;|&nbsp; عدد الزبائن: <strong>{count}</strong>"
            f"</div>"
        )

        return (
            "<div class='sm_dashboard_panel'>"
            "<div class='sm_dashboard_panel__head'>أعلى 5 زبائن من حيث الدين</div>"
            f"{hint}"
            f"<ul class='sm_dashboard_list sm_db_debt_list'>{body}</ul>"
            "</div>"
        )
