from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SmCustomer(models.Model):
    _name = "sm.customer"
    _description = "زبون السوبر ماركت"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name"
    _rec_name = "name"

    name = fields.Char(string="اسم الزبون", required=True, tracking=True, index=True)
    phone = fields.Char(string="رقم الهاتف", tracking=True)
    mobile = fields.Char(string="الموبايل")
    email = fields.Char(string="البريد الإلكتروني")
    address = fields.Text(string="العنوان")
    city = fields.Char(string="المدينة")
    notes = fields.Text(string="ملاحظات")
    active = fields.Boolean(string="نشط", default=True)

    credit_limit = fields.Float(
        string="حد الائتمان",
        digits=(10, 2),
        default=0.0,
        help="الحد الأقصى المسموح به للدين. 0 = بلا حد.",
    )
    allow_credit = fields.Boolean(string="يسمح له بالدين", default=False)

    # ── إحصائيات — store=True لتفعيل البحث والفلترة ──────
    sale_count = fields.Integer(
        string="عدد الفواتير",
        compute="_compute_stats",
        store=True,
    )
    total_sales = fields.Float(
        string="إجمالي المشتريات",
        compute="_compute_stats",
        store=True,
        digits=(10, 2),
    )
    total_debt = fields.Float(
        string="الدين الحالي",
        compute="_compute_stats",
        store=True,  # ← مخزّن حتى يمكن الفلترة عليه
        digits=(10, 2),
        tracking=True,
    )
    total_paid = fields.Float(
        string="إجمالي المدفوع",
        compute="_compute_stats",
        store=True,
        digits=(10, 2),
    )

    sale_ids = fields.One2many("sm.sale", "customer_id", string="الفواتير")
    debt_ids = fields.One2many("sm.customer.debt", "customer_id", string="سجل الديون")

    @api.depends(
        "sale_ids",
        "sale_ids.state",
        "sale_ids.final_amount",
        "sale_ids.amount_paid_customer",
        "sale_ids.payment_method",
    )
    def _compute_stats(self):
        for rec in self:
            confirmed = rec.sale_ids.filtered(lambda s: s.state == "confirmed")
            rec.sale_count = len(confirmed)
            rec.total_sales = sum(confirmed.mapped("final_amount"))
            rec.total_paid = sum(confirmed.mapped("amount_paid_customer"))
            rec.total_debt = max(rec.total_sales - rec.total_paid, 0.0)

    def action_view_sales(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": f"فواتير {self.name}",
            "res_model": "sm.sale",
            "view_mode": "list,form",
            "domain": [("customer_id", "=", self.id)],
            "context": {"default_customer_id": self.id},
        }

    def action_view_debts(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": f"ديون {self.name}",
            "res_model": "sm.customer.debt",
            "view_mode": "list,form",
            "domain": [("customer_id", "=", self.id)],
            "context": {"default_customer_id": self.id},
        }

    def action_register_payment(self):
        self.ensure_one()
        if self.total_debt <= 0:
            raise ValidationError("لا يوجد دين مستحق على هذا الزبون.")
        return {
            "type": "ir.actions.act_window",
            "name": f"تسجيل دفعة - {self.name}",
            "res_model": "sm.customer.payment",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_customer_id": self.id,
                "default_amount": self.total_debt,
            },
        }

    @api.model
    def pos_search_customers(self, search=""):
        domain = [("active", "=", True)]
        if search:
            domain += [
                "|", "|",
                ("name", "ilike", search),
                ("phone", "ilike", search),
                ("mobile", "ilike", search),
            ]
        customers = self.search(domain, limit=30, order="name asc")
        return [
            {
                "id": c.id,
                "name": c.name,
                "phone": c.phone or "",
                "mobile": c.mobile or "",
                "allow_credit": c.allow_credit,
                "credit_limit": c.credit_limit,
                "total_debt": c.total_debt,
            }
            for c in customers
        ]


class SmCustomerDebt(models.Model):
    _name = "sm.customer.debt"
    _description = "سجل دين الزبون"
    _order = "date desc, id desc"
    _rec_name = "name"

    name = fields.Char(string="المرجع", readonly=True, default="جديد", copy=False)
    customer_id = fields.Many2one(
        "sm.customer", string="الزبون",
        required=True, ondelete="restrict", index=True,
    )
    sale_id = fields.Many2one("sm.sale", string="الفاتورة", ondelete="set null")
    date = fields.Date(string="التاريخ", default=fields.Date.today, required=True)
    debt_type = fields.Selection(
        [
            ("sale", "دين من فاتورة بيع"),
            ("payment", "دفعة من الزبون"),
            ("adjustment", "تعديل يدوي"),
        ],
        string="النوع",
        required=True,
        default="sale",
    )
    amount = fields.Float(string="المبلغ", digits=(10, 2), required=True)
    notes = fields.Char(string="ملاحظة")

    # ── override create بالطريقة الصحيحة لـ Odoo 18 ──────
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "جديد") == "جديد":
                vals["name"] = (
                        self.env["ir.sequence"].next_by_code("sm.customer.debt")
                        or "DEBT/0001"
                )
        return super().create(vals_list)


class SmCustomerPayment(models.TransientModel):
    _name = "sm.customer.payment"
    _description = "تسجيل دفعة زبون"

    customer_id = fields.Many2one("sm.customer", string="الزبون", readonly=True)
    current_debt = fields.Float(
        related="customer_id.total_debt",
        string="الدين الحالي",
        readonly=True,
    )
    amount = fields.Float(string="المبلغ المدفوع", required=True, digits=(10, 2))
    date = fields.Date(string="تاريخ الدفع", default=fields.Date.today)
    payment_method = fields.Selection(
        [("cash", "نقداً"), ("bank", "تحويل بنكي"), ("card", "بطاقة")],
        string="طريقة الدفع",
        default="cash",
        required=True,
    )
    notes = fields.Char(string="ملاحظة")

    def action_confirm(self):
        self.ensure_one()
        if self.amount <= 0:
            raise ValidationError("المبلغ يجب أن يكون أكبر من صفر.")
        if self.amount > self.customer_id.total_debt:
            raise ValidationError("المبلغ المدفوع أكبر من الدين الحالي.")

        # تسجيل الدفعة في سجل الديون
        self.env["sm.customer.debt"].create({
            "customer_id": self.customer_id.id,
            "date": self.date,
            "debt_type": "payment",
            "amount": self.amount,
            "notes": self.notes or f"دفعة - {self.payment_method}",
        })

        # توزيع الدفعة على الفواتير الآجلة من الأقدم للأحدث
        unpaid_sales = self.env["sm.sale"].search(
            [
                ("customer_id", "=", self.customer_id.id),
                ("state", "=", "confirmed"),
                ("payment_method", "=", "credit"),
            ],
            order="date asc",
        )
        remaining = self.amount
        for sale in unpaid_sales:
            if remaining <= 0:
                break
            sale_remaining = sale.final_amount - sale.amount_paid_customer
            if sale_remaining <= 0:
                continue
            pay_now = min(sale_remaining, remaining)
            sale.amount_paid_customer += pay_now
            remaining -= pay_now

        self.customer_id.message_post(
            body=(
                    f"<p>تم تسجيل دفعة بقيمة <strong>{self.amount:,.2f}</strong>"
                    f" بتاريخ {self.date} — {self.payment_method}</p>"
                    + (f"<p>ملاحظة: {self.notes}</p>" if self.notes else "")
            ),
            subject="دفعة زبون",
        )
        return {"type": "ir.actions.act_window_close"}
