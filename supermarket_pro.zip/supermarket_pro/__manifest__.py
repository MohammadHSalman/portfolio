# supermarket_pro/__manifest__.py
{
    "name": "Supermarket Pro",
    "version": "18.0.1.0.0",
    "summary": "إدارة سوبر ماركت كاملة من نافذة واحدة",
    "description": """
        Supermarket Pro
        ===============
        تطبيق سوبر ماركت مستقل داخل أودو يركز على التشغيل اليومي السريع:
        - شاشة موحدة للإدارة والمتابعة
        - POS بسيط للمبيعات اليومية
        - فواتير شراء من الموردين
        - فواتير بيع وكاشير
        - تنبيهات نقص المخزون
        - تنبيهات قرب انتهاء الصلاحية
        - صلاحيات مدير ومستخدم
    """,
    "author": "Supermarket Pro",
    "website": "https://example.com",
    "category": "Retail",
    "depends": ["base", "mail", "web"],
    "assets": {
        "web.assets_backend": [
            "supermarket_pro/static/src/scss/dashboard.scss",
            "supermarket_pro/static/src/scss/pos_screen.scss",
            "supermarket_pro/static/src/js/pos_screen.js",
            "supermarket_pro/static/src/xml/pos_screen.xml",
        ],
    },
    "data": [
        "security/supermarket_security.xml",
        "security/ir.model.access.csv",
        "data/sequence_data.xml",
        "views/supermarket_views.xml",
    ],
    "application": True,
    "installable": True,
    "auto_install": False,
    "license": "LGPL-3",
    "images": ["static/description/icon.png"],
}
